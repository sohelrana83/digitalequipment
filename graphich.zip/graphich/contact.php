
<!-- header area -->

<?php include_once('header.php');?>

<img class="innerPageBanner" src="images/contact_us_banner.jpg" alt="contact-us-banner" title="contact-us-banner">



	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

						                <!------------------------------------------>
                    <section class="container">
                    	<article id="post-10" class="post-10 page type-page status-publish hentry">
                            <h2 class="page-title">Contact Us</h2>
                            <div class="entry-content">
                                <div class="innerPgCont">
<div class="pageleftPart bgOpacity">
<h2 class="addresHeading"><strong>Bangladesh Office(Digital Office LId.)</strong></h2>
<div class="addressCopy">
<p>DIGITAL OFFICE EQUIPMENT LTD.<br>
Address:<br>
53, DIT Extension Road (4th Floor), Naya Paltan, Dhaka-1000. <br />
Tel: +88 02 9335350, Mobile: 01711 051031, 01611051031<br>
E-mail : <a href="#" target="_blank">.........</a></p>
 
</div>
 
 
</div>
<div class="pageRightPart bgOpacity"><strong class="formTitleTxt">Please write here �</strong><p></p>
<div class="contactForm"><div role="form" class="wpcf7" id="wpcf7-f14-p10-o2" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form name="" action="contact.php" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="14">
<input type="hidden" name="_wpcf7_version" value="4.2.1">
<input type="hidden" name="_wpcf7_locale" value="en_US">
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f14-p10-o2">
<input type="hidden" name="_wpnonce" value="d478f9dc3b">
</div>
<p><span class="wpcf7-form-control-wrap firstname"><input type="text" name="firstname" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required nameEntry1" aria-required="true" aria-invalid="false" placeholder="First Name"></span><span class="wpcf7-form-control-wrap lastname"><input type="text" name="lastname" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required nameEntry2" aria-required="true" aria-invalid="false" placeholder="Last Name"></span></p>
<p><span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email nameEntry1" aria-required="true" aria-invalid="false" placeholder="Email Address"></span><span class="wpcf7-form-control-wrap cname"><input type="text" name="cname" value="" size="40" class="wpcf7-form-control wpcf7-text nameEntry2" aria-invalid="false" placeholder="Company Name"></span></p>
<p><span class="wpcf7-form-control-wrap textarea-591"><textarea name="textarea-591" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required txtAreaEntry" aria-required="true" aria-invalid="false" placeholder="Enter Your Message"></textarea></span></p>
<p><input type="submit" value="Send Message" class="wpcf7-form-control wpcf7-submit submitBotton"><img class="ajax-loader" src="images/ajax-loader.gif" alt="Sending ..." style="visibility: hidden;"></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
</div>
</div>
<div class="map_canvas"></div>
                                                            </div><!-- .entry-content -->
                            <div class="entry-meta">
								                            </div><!-- .entry-meta -->
                    	</article><!-- #post -->
                    </section>
                <!------------------------------------------>
							
		</div><!-- #content -->
	</div><!-- #primary -->
	
<!-- footer area -->
<?php include_once('footer.php');?>	
	