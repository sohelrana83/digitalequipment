
<!-- header area -->

<?php include_once('header.php');?>


<img class="innerPageBanner" src="images/services_banner.jpg" alt="services-banner" title="services-banner">





	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

						                <!------------------------------------------>
                    <section class="container">
                    	<article id="post-6" class="post-6 page type-page status-publish hentry">
                           
                            <div class="entry-content">
                                <div class="innerPgCont bgOpacity">
<h2 class="page-title">OUR SERVICE: </h2>					
<div class="addresHeading"><strong>Computer Sales & Services</strong></div>
<h1 style="color:white; font-size:30px;margin-top:30px;">Ready Software:</h1>
<div class="addressCopy hack_padd">
<div class="pageleftPart">
<ol class="serviceList">
<li>ERP on Garments Industry</li>
<li>Provident Fund Management Solution</li>
<li>Income TAX Management System</li>
<li>Inventory Management System</li>
<li>Store Management System</li>
<li>Poultry Farm Management System</li>
<li>Hospital Management System</li>
<li>Sales and Distribution System</li>
</ol>
</div>
<div class="pageRightPart"><img class="imageBorder" src="images/ser.jpg" alt="Pre-press-production" title="Pre-press-production"></div>
</div>
</div>
<!--<div class="innerPgCont bgOpacity marginTop20">
<div class="addresHeading"><strong>Digital production</strong></div>
<div class="addressCopy">
<div class="pageleftPart"><img class="imageBorder" src="images/digital_production.png" alt="Digital-production" title="Digital-production"></div>
<div class="pageRightPart">
<p>Given the emergence of digital channels as a force for 21st-century marketing and the proportions of budgets being allocated to digital, we believe excellence in digital production is an absolutely critical element for success today.</p>
<ol class="serviceList">
<li>E-mail &amp; Banner productions</li>
<li>Flash based design &amp; development</li>
<li>Website design &amp; development</li>
</ol>
</div>
</div>
</div>-->
                                                            </div><!-- .entry-content -->
                            <div class="entry-meta">
								                            </div><!-- .entry-meta -->
                    	</article><!-- #post -->
                    </section>
                <!------------------------------------------>
							
		</div><!-- #content -->
	</div><!-- #primary -->
	
	
<!-- footer area -->
<?php include_once('footer.php');?>