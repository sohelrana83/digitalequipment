
<!-- header area -->

<?php include_once('header.php');?>



<img class="innerPageBanner" src="images/about_us_banner.jpg" alt="about-us-banner" title="about-us-banner">






	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

						                <!------------------------------------------>
                    <section class="container">
                    	<article id="post-2" class="post-2 page type-page status-publish hentry">
                           
                            <div class="entry-content">
                                <div class="innerPgCont bgOpacity">
<div class="innerContWrap">
<h2 class="page-title">About Us</h2>
<p class="full_paraTxt">
DIGITALOFFICE LIMITED is concentrated on developing high quality software that gives our customers
superior value and more control over their operation. Already the company gained reputation in the ICT 
market due to low production & service cost as well as high quality. We are fully dedicated to develop 
software for Business Enterprises both for National & International organizations. Our goal is to develop 
cost effective errors and also to make the editing more effective and efficient. Absolute customer 
satisfaction is given highest Priority. <br /><br />
We will provide customer service both before and after the sales 
round the clock. By dedicating itself solely to information technology, company has achieved and 
outstanding reputation in the software industry for providing exceptional technology and technical 
support at reasonable prices. The customers routinely rely on company's history of providing services 
base on technology in different industries. with hundreds of thousands of end-users storing their 
mission critical date within DIGITALOFFICE's support. DIGITALOFFICE's reliability history is outstanding.  
Rather than we have following points to mention:
 
 </p>
 
<div class="addressCopy">
<div class="pageleftPart">
<ol class="serviceList">
<li>Reliable Products and services</li>
<li>Oracle certified expertise employees to ensure QoS</li>
<li>Quick delivery of relevant supports & services</li>
<li>Competitive lower price proposal</li>
<li>Reasonable lower maintenance cost</li>
<li>Global standard of products and services</li>
<li>Scope to customize products & services as per the company needs at any time.</li>
</ol>
</div>
<div class="pageRightPart"><img class="imageBorder" title="About-us" src="images/about-pic.jpg" alt="About-us"></div>
</div>
</div>
</div>
<!--
<div class="innerPgCont bgOpacity marginTop20">
<h2 class="addresHeading2"><strong>The Area of Expertise for Graphic Aid</strong></h2>
<div class="addressCopy">
<div class="pageleftPart"><img class="imageBorder alignnone" title="The-area-of-expertise-for-graphic-aid" src="images/area_of_expertise.png" alt="The-area-of-expertise-for-graphic-aid" width="450" height="300"></div>
<div class="pageRightPart">
<p>Our biggest strength is the way we manage our working ours. In addition to maintaining the local times for our respective branches, we have divided our workload in easily negotiable shifts which makes us most efficient Graphics firm when it comes to neat delivery of the project.</p>
<ol class="serviceList">
<li>Digital Production</li>
<li>Pre-Press production</li>
</ol>
</div>
</div>
</div> -->
 <!--
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;"></div>
<div id="__hggasdgjhsagd_once" style="display: none;"></div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;"></div> -->
                                                            </div><!-- .entry-content -->
                            <div class="entry-meta">
								                            </div><!-- .entry-meta -->
                    	</article><!-- #post -->
                    </section>
                <!------------------------------------------>
							
		</div><!-- #content -->
	</div><!-- #primary -->
	
	
<!-- footer area -->
<?php include_once('footer.php');?>