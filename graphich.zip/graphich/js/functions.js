<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title>Page not found | Graphic Aid</title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="http://graphic-aid.com/xmlrpc.php">
	
	<!-- media queries css -->
	<link href="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/css/media-queries.css" rel="stylesheet">
    
    
    <!-- THE STYLES -->
<link rel="stylesheet" type="text/css" href="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/css/tonic_gallery.css"/>
<link rel="stylesheet" type="text/css" href="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/css/prettyPhoto.css"/>

    
    	
	<!-- css3-mediaqueries.js for IE less than 9 -->
	<!--[if lt IE 9]>
	 <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->
	
	<!--[if IE]>
	 <script src="js/ie6PngFix.js" type="text/javascript"></script>
	<![endif]-->
	<!--End Custom Link-->
	
	<!--[if lt IE 9]>
	<script src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/js/html5.js"></script>
	<![endif]-->
	
<!-- This site is optimized with the Yoast WordPress SEO plugin v2.2.1 - https://yoast.com/wordpress/plugins/seo/ -->
<link rel="publisher" href="https://plus.google.com/+Graphicaidit"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found | Graphic Aid" />
<meta property="og:site_name" content="Graphic Aid" />
<meta property="article:publisher" content="https://www.facebook.com/graphicaidit" />
<meta property="og:image" content="http://graphic-aid.com/wp-content/uploads/2015/06/graphic-aid-logo.jpg" />
<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" content="Page not found | Graphic Aid"/>
<meta name="twitter:site" content="@graphicaidit"/>
<meta name="twitter:domain" content="Graphic Aid"/>
<meta name="twitter:image:src" content="http://graphic-aid.com/wp-content/uploads/2015/06/graphic-aid-logo.jpg"/>
<!-- / Yoast WordPress SEO plugin. -->

<link rel="alternate" type="application/rss+xml" title="Graphic Aid &raquo; Feed" href="http://graphic-aid.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Graphic Aid &raquo; Comments Feed" href="http://graphic-aid.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/graphic-aid.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.2.5"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://graphic-aid.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-fonts-css'  href='//fonts.googleapis.com/css?family=Source+Sans+Pro%3A300%2C400%2C700%2C300italic%2C400italic%2C700italic%7CBitter%3A400%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css'  href='http://graphic-aid.com/wp-content/themes/graphicaid_responsive/fonts/genericons.css?ver=2.09' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-style-css'  href='http://graphic-aid.com/wp-content/themes/graphicaid_responsive/style.css?ver=2013-07-18' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentythirteen-ie-css'  href='http://graphic-aid.com/wp-content/themes/graphicaid_responsive/css/ie.css?ver=2013-07-18' type='text/css' media='all' />
<![endif]-->
<script type='text/javascript' src='http://graphic-aid.com/wp-includes/js/jquery/jquery.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://graphic-aid.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://graphic-aid.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://graphic-aid.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.2.5" />
	<style type="text/css" id="twentythirteen-header-css">
			.site-header {
			background: url(http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/headers/circle.png) no-repeat scroll top;
			background-size: 1600px auto;
		}
		</style>
	</head>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-64764276-1', 'auto');
  ga('send', 'pageview');

</script>

<body class="error404 single-author">

<div id="wrap">
	<header class="header">
		<div class="headerTop">
			<div class="headerLeft">
				<a href="http://graphic-aid.com" class="graphic_aid_logo">
					<strong class="hide">GraphicAid: Complete Graphic Solutions</strong>
				</a>
				<div class="social-bar">
					<a href="https://www.facebook.com/graphicaidit" target="_blank"><img src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/graphic-aid-facebook.jpg" alt="Graphic Aid in Facebook" title="Graphic Aid in Facebook"></a>
					<a href="http://www.linkedin.com/company/graphic-aid" target="_blank"><img src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/graphic-aid-linkedin.jpg" alt="Graphic Aid in Linkedin" title="Graphic Aid in Linkedin"></a>
					<a href="https://twitter.com/graphicaidit" target="_blank"><img src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/graphic-aid-twitter-follower.jpg" alt="Graphic Aid in Twitter" title="Graphic Aid in Twitter"></a>
				</div>
			</div>
			<div class="menu">
				
                <div class="menu-primary-navigation-container"><ul id="menu-primary-navigation" class="nav-menu"><li id="menu-item-22" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-22"><a href="http://graphic-aid.com/">Home</a></li>
<li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-60"><a href="http://graphic-aid.com/about-us/">About Us</a></li>
<li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="http://graphic-aid.com/services/">Services</a></li>
<li id="menu-item-19" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19"><a href="http://graphic-aid.com/gallery/">Gallery</a></li>
<li id="menu-item-18" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18"><a href="http://graphic-aid.com/contact-us/">Contact Us</a></li>
</ul></div>                
			</div>
            <div class="hotNumber">Hot Number<br>13476880922</div>
		</div>
		<div class="freeTrialsBtn">
			<a href="#" id="clickMe"></a>
		</div>
		<div class="freeTrialForm bgOpacity1" id="discoverMe">
			<strong class="formTitleTxt2">Please Send Us Max 3 Files For Trial Jobs !!!</strong>
            
            <div id="text-6" class="widget contactForm widget_text">			<div class="textwidget"><div role="form" class="wpcf7" id="wpcf7-f16-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form name="" action="/wp-content/themes/graphicaid_responsive/js/functions.js?ver=2013-07-18#wpcf7-f16-o1" method="post" class="wpcf7-form" enctype="multipart/form-data" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="16" />
<input type="hidden" name="_wpcf7_version" value="4.2.1" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f16-o1" />
<input type="hidden" name="_wpnonce" value="5bb14af120" />
</div>
<p><span class="wpcf7-form-control-wrap fname"><input type="text" name="fname" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required nameEntry1" aria-required="true" aria-invalid="false" placeholder="First Name" /></span><span class="wpcf7-form-control-wrap lname"><input type="text" name="lname" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required nameEntry2" aria-required="true" aria-invalid="false" placeholder="Last Name" /></span></p>
<p><span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email nameEntry1" aria-required="true" aria-invalid="false" placeholder="Email Address" /></span><span class="wpcf7-form-control-wrap cname"><input type="text" name="cname" value="" size="40" class="wpcf7-form-control wpcf7-text nameEntry2" aria-invalid="false" placeholder="Company Name" /></span></p>
<p><span class="wpcf7-form-control-wrap file-669"><input type="file" name="file-669" value="1" size="40" class="wpcf7-form-control wpcf7-file wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span></p>
<p><span class="wpcf7-form-control-wrap file-685"><input type="file" name="file-685" value="1" size="40" class="wpcf7-form-control wpcf7-file wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </p>
<p><span class="wpcf7-form-control-wrap file-796"><input type="file" name="file-796" value="1" size="40" class="wpcf7-form-control wpcf7-file wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </p>
<p><span class="wpcf7-form-control-wrap textarea-655"><textarea name="textarea-655" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required txtAreaEntry" aria-required="true" aria-invalid="false" placeholder="Enter Your Message"></textarea></span></p>
<p><input type="submit" value="Send Message" class="wpcf7-form-control wpcf7-submit submitBotton" /></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
		</div>            
            
		</div>
	</header>
    
    
    
    






	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

			<header class="page-header">
				<h1 class="page-title">Not Found</h1>
			</header>

			<div class="page-wrapper">
				<div class="page-content">
					<h2>Page Does Not Exists!!!! *** PLEASE Visit HOME Page. ***</h2>
					<p></p>

									</div><!-- .page-content -->
			</div><!-- .page-wrapper -->

		</div><!-- #content -->
	</div><!-- #primary -->

<footer class="footer">
    <div class="copyright">
        &copy; 2014. All rights are reserved by <a href="http://www.graphic-aid.com">graphic-aid.com</a>	
    </div>
</footer>

	<div id="bgImgChange">
	<img class="bgfade" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/background_images1.jpg" alt="Background-image1">
	<img class="bgfade" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/background_images2.jpg" alt="Background-image2">
	<img class="bgfade" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/background_images3.jpg" alt="Background-image3">
	<img class="bgfade" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/background_images4.jpg" alt="Background-image4">
	<img class="bgfade" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/background_images5.jpg" alt="Background-image5">
	<img class="bgfade" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/images/background_images6.jpg" alt="Background-image6">
	</div>    
    
    <!-- SCRIPTS -->
	<script type="text/javascript" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/js/jquery.min.js"></script>
	<script type="text/javascript" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/js/jquery-easing.js"></script>
	<script type="text/javascript" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="http://graphic-aid.com/wp-content/themes/graphicaid_responsive/js/portfolio-setter.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	<!-- END SCRIPTS -->
    
    
	<script type="text/javascript">
		
		/*$(window).load(function(){
			$('img.bgfade').hide();
			var dg_H = $(window).height();
			var dg_W = $(window).width();
			//alert(dg_W + " - " + dg_H);
			$('#bgImgChange').css({'height':dg_H,'width':dg_W});
			function animation() {
				$("#bgImgChange img.bgfade").first().appendTo('#bgImgChange').fadeOut(1500);
				$("#bgImgChange img").first().fadeIn(1500);
				setTimeout(anim, 6000);
			}
			animation();
		})*/
		
		$(window).load(function(){
		$('img.bgfade').hide();
		var dg_H = $(window).height();
		var dg_W = $(window).width();
		$('#bgImgChange').css({'height':dg_H,'width':dg_W});
		function anim() {
		    $("#bgImgChange img.bgfade").first().appendTo('#bgImgChange').fadeOut(1500);
		    $("#bgImgChange img").first().fadeIn(1500);
		    setTimeout(anim, 6000);
		}
		anim(); });
		
		//$(window).resize(function(){window.location.href=window.location.href})
		
		function init_map(){
			var myOptions = {
				zoom:14,
				center:new google.maps.LatLng(23.75902313789197,90.38670257354124),
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};
			map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
			marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(23.75902313789197, 90.38670257354124)});
			infowindow = new google.maps.InfoWindow({content:"<b>Graphic Aid :</b>TMC Building (4th Floor)<br/>52 New Eskaton Road Dhaka-1000,<br/>Bangladesh." });
			google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});
			infowindow.open(map,marker);
		}
		google.maps.event.addDomListener(window, 'load', init_map);
		
		
		
		
		$('#portfolio_wavy').portfolioSetter({xmlSource:'http://graphic-aid.com/wp-content/themes/graphicaid_responsive/portfolio.xml', wavyAnimation:true});
		 
		

		$('#clickMe').click(function() {
            if($("#discoverMe").is(":hidden")){
					$('#discoverMe').fadeIn("slow");
			}
			else{
				$('#discoverMe').fadeOut("slow");
			}
        });
		$("#discoverMe").mouseleave(function(){
			$(this).fadeOut();
		});

		$(document).ready(function(){
			$('.port_cat').click();
		});

		var flashvars = {};
		var params = { wmode: "opaque" };
		var attributes = {};
		 
		swfobject.embedSWF("movie.swf", "flash", "600", "340", "7",
		                  "expressinstall.swf", flashvars, params, attributes);
		
		
	</script>
	</div>
</div>
<style type="text/css">.credits_off {display:none;}</style><div class="hit-counter-max" align="center"><img src='http://graphic-aid.com/wp-content/plugins/hit-counter-max/designs/Basic/2/8.gif'><img src='http://graphic-aid.com/wp-content/plugins/hit-counter-max/designs/Basic/2/0.gif'><img src='http://graphic-aid.com/wp-content/plugins/hit-counter-max/designs/Basic/2/7.gif'><img src='http://graphic-aid.com/wp-content/plugins/hit-counter-max/designs/Basic/2/6.gif'><img src='http://graphic-aid.com/wp-content/plugins/hit-counter-max/designs/Basic/2/9.gif'></div><script type='text/javascript' src='http://graphic-aid.com/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/graphic-aid.com\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://graphic-aid.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.2.1'></script>
<script type='text/javascript' src='http://graphic-aid.com/wp-content/themes/graphicaid_responsive/js/functions.js?ver=2013-07-18'></script>

<a href="http://clashofclanshacksfree.com/" target="_blank" style="color:#333">clash of clans gem hack</a>
</body>
</html>

