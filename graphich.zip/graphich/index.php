<!-- header area -->

<?php include_once('header.php');?>
    
<!-- index body area -->    
<?php include_once('index-body.php');?>


<!-- footer area -->
<?php include_once('footer.php');?>