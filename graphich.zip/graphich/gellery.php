
<!-- header area -->

<?php include_once('header.php');?>


<img class="innerPageBanner" src="images/gallery_banner.jpg" alt="gallery-banner" title="gallery-banner">




	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

						                <!------------------------------------------>
                    <section class="container">
                    	<article id="post-8" class="post-8 page type-page status-publish hentry">
                            
                            <div class="entry-content">
                                <div class="innerPgCont bgOpacity">
<h2 class="page-title">Gallery:</h2>								
 
<h2 class="full_paraTxt2">Board of Directors:</h2>
 

 <table border="1px" style="color:white; background:none;text-align:left; width:100%;">
	<tr>
		<td><b>S. N.</b></td>
		<td><b>Name, Addresses, Descriptions and Nationality of the Subscribers</b></td>
		<td><b>Designation</b></td>
	</tr>
	<tr>
		<td><b>01</b></td>
		<td>
			<b>Name: Saiful Islam</b><br />
				Father's Name : Abul Kalam <br />

				Mother's Name: Noorjahan Begum<br />

				Address : Shop No. 4/73, Eastern Plus, 145, Shantinagar, Paltan, <br />

				Dhaka-1217 <br />

				Date Of Birth: 01/01/1984<br />

				Nationality : Bangladeshi<br />

				Profession : Business<br />

				TIN : 893234369134 <br />

				National ID: 2691649426443<br />

				Mobile No. 01611051031<br />

				Email: saifulislam208@gmail.com<br />
						
		</td>
		<td>Managing Director</td>
	</tr>
	<tr>
		<td><b>02</b></td>
		<td>
			<b>Name: Farook Hossain</b><br />
			Father�s Name : Muhammad Amin Ullah<br />

			Mother's Name: Ayesha Begum<br />

			Address : 143, Shantinagar, Al-amin Tower, Flat No. B-8, Paltan, <br />

			Dhaka-1217   <br />

			Date Of Birth: 21 Feb 1984<br />

			Nationality : Bangladeshi<br />

			Profession : Business<br />

			TIN : 558466633632<br />

			National ID: 5115811694347<br />

			Mobile No. 01711233107<br />

			Email: farookhossain21@gmail.com<br />
					
		</td>
		<td>Director</td>
	</tr>
 </table>
 
 
</div>
<div id="main_container">
<div class="center">
<div id="portfolio_wavy" style="width: 1024px; height: auto; overflow: hidden;">
<div id="portfolio_categories">
 
<h1 style="color:color:white;text-align:center;text-width:bold;">Gallery</h1>
 
<div id="portfolio_categories_right"></div>
</div>
<div style="width: 1054px; height: 620px; float: left; margin-left: 0px;">
	<div class="page_wrapper" style="float: left; width: 1054px; height: 620px;">
		 
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/01.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/02.png"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/03.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/04.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
			<img src="Gallery/05.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/06.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
			<img src="Gallery/07.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/08.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/09.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/10.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/11.png"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/12.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/13.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/14.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/15.jpg"></a>
		</div>
		<div class="portfolio_item" style="display: block; opacity: 1;">
			<a rel="lightbox[portfolio_wavy]" class="single_image" href="#" title="">
		<img src="Gallery/16.png"></a>
		</div>
		
	</div>
 </div>
 
</div>
</div>
</div>
 
                                                            </div><!-- .entry-content -->
                             
                    	</article><!-- #post -->
                    </section>
                <!------------------------------------------>
							
		</div><!-- #content -->
	</div>
	
	
<?php include_once('footer.php');?>	