<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
        <!------------------------------------------>
            <section class="container">
                
 
                
                
            <div class="welcomeMess">
				 
					<h2 class="widgettitle">Company Details:</h2>
					 
					<p>DIGITALOFFICE EQUIPMENT LTD. is an ICT as well as ITES based company and as an oracle Gold partner
						in Bangladesh. There are no boundaries to the solutions we bring to meet your most challenging 
						business requirements. Consultants of DIGITALOFFICE EQUIPMENT Limited possess notable experience-
						specializing in implementing Oracle business applications for more than 4 years. <br /><br /> DIGITALOFFICE 
						EQUIPMENT Limited has been exclusively focused on providing Oracle ERP business solutions. Our 
						company has grown to over highly relates to the industries we serve. DIGITALOFFICE EQUIPMENT 
						Limited established within a short span of time as a trust worthy Oracle ERP vendor in Bangladesh.<br><br>
						
						DIGITALOFFICE EQUIPMENT Limited is results-driven and maintains a firm commitment to customer
						satisfaction. We maximize your return will skilled, accomplished consultants who understand the 
						necessity of adding value to your business.<span class="strongText"> DIGITALOFFICE EQUIPMENT LTD.</span></p>
					 
				 
			</div>
                
                
            </section>
         <!------------------------------------------>
    </div><!-- #content -->
</div><!-- #primary -->

<!--
<section class="ftr_widget">
	<div id="text-5" class="widget widget_text">
	<h2 class="widgettitle">Our present work</h2>
			<div class="textwidget">
			<ul class="workListCol1">
        <li>Photoshop Clipping Path/contouring Services</li>
        <li>Photoshop Transparent Masking</li>
        <li>Photoshop Translucent Masking</li>
        <li>Background Removing Service</li>
        <li>Multiple Clipping Path/ Color Path/Color Correction</li>
        <li>Channel Masking/Soft Mask in Photoshop</li>
        <li>Layer Masking Service</li>
    </ul>
     <ul class="workListCol2">
        <li>Image Shadowing (natural, drop /reflection shadow)	</li>
        <li>Photo Retouching &amp; Restoration</li>
        <li>Glamour Enhancement Service</li>
        <li>Image Cleaning Service</li>
        <li>Cropping/ resizing/ Straightening Image</li>
        <li>Magazine &amp; Newspaper Layout Design Service</li>
    </ul>
     <ul class="workListCol3">
        <li>Brochure, Poster and Banner Design</li>
        <li>Corporate Identity Design</li>
        <li>Page makeup Design</li>
        <li>Catalog Production Design</li>
        <li>Raster to Vector Conversion Service</li>
        <li>Language Conversion Service</li>
        <li>Adaptation</li>
    </ul></div>
		</div>
		</section>
-->
<!-- <section class="container testimonials_widget">
	<div id="text-7" class="widget widget_text"><h2 class="widgettitle">Testimonials</h2>
			<div class="textwidget"><blockquote class="blockquote">I have chosen "Graphic-aid" for masking and Silhouette for my products and Model work as they are maintaining my time and quality but they are not expensive.
<cite>Mark<span>Mark Photography<br>Rancho Santa Margarita, USA</span></cite></blockquote>

<blockquote class="blockquote">We are pleased to Graphic-aid works for retouching, clipping and cropping our products as per our requirement. They are also very much professional with the deadline. Thank you very much "Graphic-aid".
<cite>Jeannie and Maia <span>New York, USA</span></cite></blockquote>
 
</div>
		</div></section>-->